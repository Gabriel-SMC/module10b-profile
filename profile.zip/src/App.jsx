import React from 'react';
import Profile from './Profile';

function App() {
  return (
    <div style={appStyles.container}>
      <Profile
        name="Sam"
        occupation="Grid Programmer"
        funFact="Trained on 8-bit compilers"
        quote="The Grid. A digital frontier..."
      />
    </div>
  );
}

const appStyles = {
  container: {
    backgroundColor: '#000',
    minHeight: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '20px',
  },
};

export default App;