import React, { useState } from 'react';

const Profile = ({ name, occupation, funFact, quote }) => {
  const [showQuote, setShowQuote] = useState(false);

  const toggleQuote = () => {
    setShowQuote((prev) => !prev);
  };

  return (
    <div style={styles.arcadeCabinet}>
      <div style={styles.screen}>
        <div style={styles.header}>
          <p style={styles.highScore}>1UP - HIGH SCORE</p>
          <p style={styles.score}>99990</p>
        </div>

        <div style={styles.profileBox}>
          <h1 style={styles.name}>{name.toUpperCase()}</h1>
          <p style={styles.meta}>
            <span style={styles.label}>CLASS:</span> {occupation}
          </p>
          <p style={styles.meta}>
            <span style={styles.label}>PERK:</span> {funFact}
          </p>

          {showQuote && (
            <div style={styles.quoteBox}>
              <p style={styles.quoteText}>"{quote}"</p>
            </div>
          )}
        </div>

        <button style={styles.arcadeButton} onClick={toggleQuote}>
          {showQuote ? 'PAUSE GAME' : 'INSERT COIN / PRESS START'}
        </button>
      </div>
    </div>
  );
};

const styles = {
  arcadeCabinet: {
    backgroundColor: '#111',
    border: '4px solid #f0f',
    borderRadius: '12px',
    padding: '20px',
    maxWidth: '400px',
    margin: '20px auto',
    boxShadow: '0 0 15px #f0f, inset 0 0 10px #0ff',
    fontFamily: '"Courier New", Courier, monospace',
  },
  screen: {
    backgroundColor: '#050515',
    border: '3px solid #0ff',
    borderRadius: '6px',
    padding: '20px',
    color: '#0ff',
    textShadow: '0 0 5px #0ff',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    color: '#ff0',
    textShadow: '0 0 5px #ff0',
    fontSize: '0.85rem',
    marginBottom: '15px',
  },
  highScore: { margin: 0 },
  score: { margin: 0 },
  profileBox: {
    marginBottom: '20px',
  },
  name: {
    color: '#ff007f',
    textShadow: '0 0 8px #ff007f',
    fontSize: '1.8rem',
    margin: '0 0 10px 0',
    textAlign: 'center',
    letterSpacing: '2px',
  },
  meta: {
    fontSize: '0.95rem',
    lineHeight: '1.4',
    margin: '8px 0',
    color: '#fff',
  },
  label: {
    color: '#0ff',
    fontWeight: 'bold',
  },
  quoteBox: {
    marginTop: '15px',
    padding: '10px',
    backgroundColor: 'rgba(255, 0, 255, 0.1)',
    borderLeft: '3px solid #f0f',
    animation: 'fadeIn 0.3s ease-in',
  },
  quoteText: {
    margin: 0,
    color: '#00ffcc',
    fontStyle: 'italic',
    fontSize: '0.9rem',
    textShadow: '0 0 5px #00ffcc',
  },
  arcadeButton: {
    width: '100%',
    padding: '12px',
    backgroundColor: '#ff0',
    color: '#000',
    border: 'none',
    fontWeight: 'bold',
    fontSize: '0.9rem',
    cursor: 'pointer',
    boxShadow: '0 4px 0 #b3b300, 0 0 10px #ff0',
    transition: 'all 0.1s ease',
  },
};

export default Profile;